package view.BackingBeans;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import javax.servlet.http.HttpSession;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;

import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;

import oracle.adf.view.rich.context.AdfFacesContext;



import oracle.binding.BindingContainer;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class SearchPageBean {
    private RichSelectOneChoice professionalTypeBind;
    private RichInputText grossTurnOverBind;
    private RichInputText noOfYearsBind;
    private RichInputText monthlyIncomeBind;
    private RichPanelFormLayout searchPfBind;

    public SearchPageBean() {
    }

    public String SearchAction() {
        // Add event code here...
      return null;
       
    }

    public void employmentTypeVCL(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        
        
        
        
        
        
    }

    public String action_search() {
        // Add event code here...
        try {
            BindingContainer bc =
                (BindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding searchLenders =
                bc.getOperationBinding("searchLenders");

            searchLenders.execute();
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }

//        return null;
        return null;
    }

    public void setProfessionalTypeBind(RichSelectOneChoice professionalTypeBind) {
        this.professionalTypeBind = professionalTypeBind;
    }

    public RichSelectOneChoice getProfessionalTypeBind() {
        return professionalTypeBind;
    }

    public void setGrossTurnOverBind(RichInputText grossTurnOverBind) {
        this.grossTurnOverBind = grossTurnOverBind;
    }

    public RichInputText getGrossTurnOverBind() {
        return grossTurnOverBind;
    }

    public void setNoOfYearsBind(RichInputText noOfYearsBind) {
        this.noOfYearsBind = noOfYearsBind;
    }

    public RichInputText getNoOfYearsBind() {
        return noOfYearsBind;
    }

    public void setMonthlyIncomeBind(RichInputText monthlyIncomeBind) {
        this.monthlyIncomeBind = monthlyIncomeBind;
    }

    public RichInputText getMonthlyIncomeBind() {
        return monthlyIncomeBind;
    }

    public String reset_action() {
        // Add event code here...
        
        try {
            
            System.out.println("----------- Inside Reset Action in Bean-----");
            BindingContainer bc =
                (BindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding resetAction =
                bc.getOperationBinding("resetAction");
            
            
            AdfFacesContext.getCurrentInstance().addPartialTarget(this.searchPfBind);
            
            
            
            
            

            resetAction.execute();
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
        
        
        return null;
    }

    public void setSearchPfBind(RichPanelFormLayout searchPfBind) {
        this.searchPfBind = searchPfBind;
    }

    public RichPanelFormLayout getSearchPfBind() {
        return searchPfBind;
    }

    public String Select_Loan_Action() {
        // Add event code here...

        try {
            ExternalContext context =
                FacesContext.getCurrentInstance().getExternalContext();

            HttpSession session = (HttpSession)context.getSession(false);

            if (session.getAttribute("BorrowerId") != null) {

                /**
             *  Proceed to submit final details page
             */


            } else {
                /**
             *  Proceed to Login Page but save the data in cache
             */


                BindingContainer bc =
                    BindingContext.getCurrent().getCurrentBindingsEntry();
                OperationBinding dataInCache =
                    bc.getOperationBinding("setSearchedDataInCache");

                dataInCache.execute();


                return "toLoginPage";
            }


        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }

        return null;
    }
    
    
    
  
    
    
    
    
    
    
}
