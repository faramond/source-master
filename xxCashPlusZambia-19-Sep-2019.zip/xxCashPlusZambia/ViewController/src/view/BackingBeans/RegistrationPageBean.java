package view.BackingBeans;

import oracle.adf.model.BindingContext;
import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

public class RegistrationPageBean {
    private RichInputText setPasswordBind;
    private RichInputText confirmPasswordBinding;

    public RegistrationPageBean() {
    }

    public String submit_registration() {
        // Add event code here...

        try {
            BindingContainer bc =
                BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding registrationProcess =
                bc.getOperationBinding("registrationProcess");

           String returnedMsg= (String)registrationProcess.execute();
            
            if(returnedMsg!=null && !returnedMsg.isEmpty() && returnedMsg.equalsIgnoreCase("toLogin")) {
                
                return "toLogin";
            }


        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
        
        return null;
    }

    public void setSetPasswordBind(RichInputText setPasswordBind) {
        this.setPasswordBind = setPasswordBind;
    }

    public RichInputText getSetPasswordBind() {
        return setPasswordBind;
    }

    public void setConfirmPasswordBinding(RichInputText confirmPasswordBinding) {
        this.confirmPasswordBinding = confirmPasswordBinding;
    }

    public RichInputText getConfirmPasswordBinding() {
        return confirmPasswordBinding;
    }
}
