package view.BackingBeans;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpSession;

import oracle.adf.model.BindingContext;

import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

public class LoginBean {
    private RichInputText emailId;
    private RichInputText password;
    private RichSelectBooleanCheckbox termAndPolicy;

    public LoginBean() {
    }

    public String action_signin() {
        // Add event code here...

        try {

            String emailIdEntered =(String) emailId.getValue();
            System.out.println("========== Email Id Entered =========== "+emailIdEntered);

            String passwordEntered = (String)password.getValue();
            System.out.println("========== passwordEntered Entered =========== "+passwordEntered);

            BindingContainer bc =
                BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding signInAction =
                bc.getOperationBinding("signInAction");
            Map map = signInAction.getParamsMap();
            map.put("emailId", emailIdEntered);
            map.put("password", passwordEntered);

            Map<String, Object> flowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
            flowScope.put("Source", "login");
            

            String returnedMessage  =(String)signInAction.execute();
            System.out.println("=============== returnedMessage ================ "+returnedMessage);


            ExternalContext ext = FacesContext.getCurrentInstance().getExternalContext();

            


            if(returnedMessage!=null && !returnedMessage.isEmpty() && returnedMessage.contains("toLandingPage")) {
                ADFContext.getCurrent().getPageFlowScope().put("passwordMatch", "Y");
                String[] returnedArray=returnedMessage.split("~");
                String userId=returnedArray[1];
                System.out.println("================= Returned UserId is ============== "+userId);
                HttpSession session = (HttpSession)ext.getSession(false);
                session.setAttribute("LogInUserId", userId);
                
                
                
                return "toLandingPage";
            }
            else if(returnedMessage!=null && !returnedMessage.isEmpty() && returnedMessage.equalsIgnoreCase("PasswordNotMatch")){
                
                ADFContext.getCurrent().getPageFlowScope().put("passwordMatch", "N");
                
                return null;
                
            }
            
            
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }

  
        return null;
    }

    public void setEmailId(RichInputText emailId) {
        this.emailId = emailId;
    }

    public RichInputText getEmailId() {
        return emailId;
    }

    public void setPassword(RichInputText password) {
        this.password = password;
    }

    public RichInputText getPassword() {
        return password;
    }

    public void setTermAndPolicy(RichSelectBooleanCheckbox termAndPolicy) {
        this.termAndPolicy = termAndPolicy;
    }

    public RichSelectBooleanCheckbox getTermAndPolicy() {
        return termAndPolicy;
    }
}
