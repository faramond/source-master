package view.BackingBeans;

import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.layout.RichPanelGridLayout;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.BindingContainer;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class LandingPageBean {
    private RichPopup occupationPopupBind;
    private RichPanelGridLayout loanDetailsBind;
    private RichPanelGridLayout occupationDetailsBind;

    public LandingPageBean() {
    }


    public String action_PersonalLoanIcon() {
        // Add event code here...

        try {
            AdfFacesContext adfFacesContext =
                AdfFacesContext.getCurrentInstance();
            Map<String, Object> pageFlowScope =
                adfFacesContext.getPageFlowScope();

            pageFlowScope.put("SelectedLoanTypeId", "PL");


            DCBindingContainer dbc =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            DCIteratorBinding dcIteratorBinding =
                (DCIteratorBinding)dbc.get("SearchLenderTransVO1Iterator");
            
            
            DCIteratorBinding lenderLoanDetailsIteratorBinding =
                (DCIteratorBinding)dbc.get("LenderLoanDetailsVO1Iterator");
            ViewObject lenderLoanDetailsVO = lenderLoanDetailsIteratorBinding.getViewObject();
            lenderLoanDetailsVO.executeEmptyRowSet();


            Row firstRowSearchTransVO =
                dcIteratorBinding.getViewObject().first();

            firstRowSearchTransVO.setAttribute("SelectedLoanType",
                                               "Personal Loan");


        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
        


        return "toSearch";
    }

    public void setOccupationPopupBind(RichPopup occupationPopupBind) {
        this.occupationPopupBind = occupationPopupBind;
    }

    public RichPopup getOccupationPopupBind() {
        return occupationPopupBind;
    }

    public String action_proceed() {
        // Add event code here...
        
        
        
        
        
        
        
        
        return "toOccupationDetails";
    }

    public String action_proceed_occupationDetails() {
        // Add event code here...


        try {
            ;
           BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("proceedActionOccupationDetailsLandingPage").execute();
            
            AdfFacesContext.getCurrentInstance().getPageFlowScope().put("disableLoanDetails", "Y");


        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
        
        
        
        
        return "toSummaryPage";
    }

    public String action_edit_loan_details() {
        // Add event code here...

        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("disableLoanDetails", "N");
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getLoanDetailsBind());


        return null;
    }

    public void setLoanDetailsBind(RichPanelGridLayout loanDetailsBind) {
        this.loanDetailsBind = loanDetailsBind;
    }

    public RichPanelGridLayout getLoanDetailsBind() {
        return loanDetailsBind;
    }

    public String edit_occupation_action() {
        // Add event code here...
        
       
                                                        
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("disableOccupationDetails", "N");
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getOccupationDetailsBind());
                                               
                                                        
                                                        
        return null;
    }

    public void setOccupationDetailsBind(RichPanelGridLayout occupationDetailsBind) {
        this.occupationDetailsBind = occupationDetailsBind;
    }

    public RichPanelGridLayout getOccupationDetailsBind() {
        return occupationDetailsBind;
    }

    public String action_submit() {
        // Add event code here...
        
       String returnedValue= (String)BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("submit").execute();
       System.out.println("========== returned Values === "+returnedValue);
       
       if(returnedValue!=null && !returnedValue.isEmpty() && returnedValue.equalsIgnoreCase("success")) {
           
           FacesContext ctx = FacesContext.getCurrentInstance();
           FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_INFO, "Application Submitted Successfully.Check status in My Request", "");
           ctx.addMessage(null,fm);
           
           
           return "toLandingPage";
           
       }
       else{
           
           FacesContext ctx = FacesContext.getCurrentInstance();
           FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Exception Occured,Please contact Support Team", "");
           ctx.addMessage(null,fm);
           
       }
        
        
        return null;
    }
}
